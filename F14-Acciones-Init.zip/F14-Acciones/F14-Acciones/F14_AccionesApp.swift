//
//  F14_AccionesApp.swift
//  F14-Acciones
//
//  Created by Juan Gabriel Gomila Salas on 30/9/23.
//

import SwiftUI

@main
struct F14_AccionesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
