//
//  F10_ProyectoArticulosApp.swift
//  F10-ProyectoArticulos
//
//  Created by Juan Gabriel Gomila Salas on 24/9/23.
//

import SwiftUI

@main
struct F10_ProyectoArticulosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
